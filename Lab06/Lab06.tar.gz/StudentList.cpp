#include "StudentList.h"

void AddStudent(int* numberOfStudents, char*** namesList, char*** surnamesList, int** yearsList,const char* firstname, const char* secondname, const char* surname, int year) {

	static int size = 256;
	static char** list = new char*[3];
	for(int i = 0; i < 3; i++) {
		list[i] = new char[size];
	}

	int i = 0;
	while(firstname[i] != '\0'){
		list[0][i] = firstname[i];
		i++;
	}
	list[0][i] = ' ';
	i++;
	int j = 0;
	while(secondname[j] != '\0'){
		list[0][i] = secondname[j];
		//printf("%c", list[0][i]);
		j++;
		i++;
	}
	list[0][i] = '\0';

	(*numberOfStudents)++;

	*namesList = list;

}

void PrintListContent (int numberOfStudents, char** namesList) { 
	for(int i = 0; i < 3; i++) {
		printf("%s\n", namesList[i]);
	}
}